#include "Object.h"

extern VERTEX* Triangle;
extern unsigned long * Indices;
extern UINT count_vertex;
extern UINT count_indices;
VOID CreateSphere(UINT count)
{
    UINT A = UINT(sqrt(count));
    UINT B = UINT(sqrt(count) / 2);
    Triangle = new VERTEX[(A + 1) * (B + 1)];
    Indices = new unsigned long[A * B * 2 * 3];
    count_vertex = (A + 1) * (B + 1);
    count_indices = A * B * 2 * 3;
    //���������� ������� ������, ����. �����.
    //� ������� ��� ����������� ��������� ��� �� ������
    for (UINT i = 0; i < B + 1; i++)
        for (UINT j = 0; j < A + 1; j++)
        {
            Triangle[i * (A + 1) + j].pos =
                XMFLOAT3(cos(XM_PI * j * 2.0f / A) * sin(XM_PI / B * i),
                    cos(XM_PI / B * i),
                    sin(XM_PI * j * 2.0f / A) * sin(XM_PI / B * i));
            if (j == A) Triangle[i * (A + 1) + j].pos = Triangle[i * (A + 1)].pos;
            Triangle[i * (A + 1) + j].normal = Triangle[i * (A + 1) + j].pos;
            Triangle[i * (A + 1) + j].color = XMFLOAT4(0.5f, 0.2f, 0.7f, 1.0f);
            Triangle[i * (A + 1) + j].tex.x =  j / (FLOAT)A;
            Triangle[i * (A + 1) + j].tex.y =  i / (FLOAT)B;
        }
    //������ ��������
    for (UINT i = 0; i < B; i++)
        for (UINT j = 0; j < A; j++)
        {
            Indices[(i * A + j) * 6] = i * (A + 1) + j;
            Indices[(i * A + j) * 6 + 1] = (i + 1) * (A + 1) + j;
            Indices[(i * A + j) * 6 + 2] = (i + 1) * (A + 1) + j + 1;
            Indices[(i * A + j) * 6 + 3] = (i + 1) * (A + 1) + j + 1;
            Indices[(i * A + j) * 6 + 4] = i * (A + 1) + j + 1;
            Indices[(i * A + j) * 6 + 5] = i * (A + 1) + j;
        }
}
VOID CreateCubePoligon()
{
    Triangle = new VERTEX[28];
    Indices = new unsigned long[40];
    count_vertex = 28;
    count_indices = 40;
    Triangle[0].pos.x = 0.5f;
    Triangle[0].pos.y = 0.5f;
    Triangle[0].pos.z = 0.5f;
    Triangle[0].color = XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f);
    Triangle[0].tex.x = 0.0;
    Triangle[0].tex.y = 0.0;

    Triangle[1].pos.x = 0.5f;
    Triangle[1].pos.y = -0.5f;
    Triangle[1].pos.z = 0.5f;
    Triangle[1].color = XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f);
    Triangle[1].tex.x = 0.0;
    Triangle[1].tex.y = 1.0;

    Triangle[2].pos.x = -0.5f;
    Triangle[2].pos.y = -0.5f;
    Triangle[2].pos.z = 0.5f;
    Triangle[2].color = XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f);
    Triangle[2].tex.x = 1.0;
    Triangle[2].tex.y = 1.0;

    Triangle[3].pos.x = -0.5f;
    Triangle[3].pos.y = 0.5f;
    Triangle[3].pos.z = 0.5f;
    Triangle[3].color = XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f);
    Triangle[3].tex.x = 1.0;
    Triangle[3].tex.y = 0.0;

    Triangle[4].pos.x = -0.5f;
    Triangle[4].pos.y = 0.5f;
    Triangle[4].pos.z = 0.5f;
    Triangle[4].color = XMFLOAT4(0.0f, 1.0f, 0.0f, 1.0f);
    Triangle[4].tex.x = 0.0;
    Triangle[4].tex.y = 0.0;

    Triangle[5].pos.x = -0.5f;
    Triangle[5].pos.y = -0.5f;
    Triangle[5].pos.z = 0.5f;
    Triangle[5].color = XMFLOAT4(0.0f, 1.0f, 0.0f, 1.0f);
    Triangle[5].tex.x = 0.0;
    Triangle[5].tex.y = 1.0;

    Triangle[6].pos.x = -0.5f;
    Triangle[6].pos.y = -0.5f;
    Triangle[6].pos.z = -0.5f;
    Triangle[6].color = XMFLOAT4(0.0f, 1.0f, 0.0f, 1.0f);
    Triangle[6].tex.x = 1.0;
    Triangle[6].tex.y = 1.0;

    Triangle[7].pos.x = -0.5f;
    Triangle[7].pos.y = 0.5f;
    Triangle[7].pos.z = -0.5f;
    Triangle[7].color = XMFLOAT4(0.0f, 1.0f, 0.0f, 1.0f);
    Triangle[7].tex.x = 1.0;
    Triangle[7].tex.y = 0.0;

    Triangle[8].pos.x = -0.5f;
    Triangle[8].pos.y = 0.5f;
    Triangle[8].pos.z = -0.5f;
    Triangle[8].color = XMFLOAT4(1.0f, 1.0f, 0.0f, 1.0f);
    Triangle[8].tex.x = 0.0;
    Triangle[8].tex.y = 0.0;

    Triangle[9].pos.x = -0.5f;
    Triangle[9].pos.y = -0.5f;
    Triangle[9].pos.z = -0.5f;
    Triangle[9].color = XMFLOAT4(1.0f, 1.0f, 0.0f, 1.0f);
    Triangle[9].tex.x = 0.0;
    Triangle[9].tex.y = 1.0;

    Triangle[10].pos.x = 0.5f;
    Triangle[10].pos.y = -0.5f;
    Triangle[10].pos.z = -0.5f;
    Triangle[10].color = XMFLOAT4(1.0f, 1.0f, 0.0f, 1.0f);
    Triangle[10].tex.x = 1.0;
    Triangle[10].tex.y = 1.0;

    Triangle[11].pos.x = 0.5f;
    Triangle[11].pos.y = 0.5f;
    Triangle[11].pos.z = -0.5f;
    Triangle[11].color = XMFLOAT4(1.0f, 1.0f, 0.0f, 1.0f);
    Triangle[11].tex.x = 1.0;
    Triangle[11].tex.y = 0.0;

    Triangle[12].pos.x = 0.5f;
    Triangle[12].pos.y = 0.5f;
    Triangle[12].pos.z = -0.5f;
    Triangle[12].color = XMFLOAT4(1.0f, 0.0f, 1.0f, 1.0f);
    Triangle[12].tex.x = 0.0;
    Triangle[12].tex.y = 0.0;

    Triangle[13].pos.x = 0.5f;
    Triangle[13].pos.y = -0.5f;
    Triangle[13].pos.z = -0.5f;
    Triangle[13].color = XMFLOAT4(1.0f, 0.0f, 1.0f, 1.0f);
    Triangle[13].tex.x = 0.0;
    Triangle[13].tex.y = 1.0;

    Triangle[14].pos.x = 0.5f;
    Triangle[14].pos.y = -0.5f;
    Triangle[14].pos.z = 0.5f;
    Triangle[14].color = XMFLOAT4(1.0f, 0.0f, 1.0f, 1.0f);
    Triangle[14].tex.x = 1.0;
    Triangle[14].tex.y = 1.0;

    Triangle[15].pos.x = 0.5f;
    Triangle[15].pos.y = 0.5f;
    Triangle[15].pos.z = 0.5f;
    Triangle[15].color = XMFLOAT4(1.0f, 0.0f, 1.0f, 1.0f);
    Triangle[15].tex.x = 1.0;
    Triangle[15].tex.y = 0.0;

    Triangle[16].pos.x = 0.5f;
    Triangle[16].pos.y = 0.5f;
    Triangle[16].pos.z = -0.5f;
    Triangle[16].color = XMFLOAT4(0.0f, 0.0f, 1.0f, 1.0f);
    Triangle[16].tex.x = 0.0;
    Triangle[16].tex.y = 0.0;

    Triangle[17].pos.x = 0.5f;
    Triangle[17].pos.y = 0.5f;
    Triangle[17].pos.z = 0.5f;
    Triangle[17].color = XMFLOAT4(0.0f, 0.0f, 1.0f, 1.0f);
    Triangle[17].tex.x = 0.0;
    Triangle[17].tex.y = 1.0;

    Triangle[18].pos.x = -0.5f;
    Triangle[18].pos.y = 0.5f;
    Triangle[18].pos.z = 0.5f;
    Triangle[18].color = XMFLOAT4(0.0f, 0.0f, 1.0f, 1.0f);
    Triangle[18].tex.x = 1.0;
    Triangle[18].tex.y = 1.0;

    Triangle[19].pos.x = -0.5f;
    Triangle[19].pos.y = 0.5f;
    Triangle[19].pos.z = -0.5f;
    Triangle[19].color = XMFLOAT4(0.0f, 0.0f, 1.0f, 1.0f);
    Triangle[19].tex.x = 1.0;
    Triangle[19].tex.y = 0.0;

    Triangle[20].pos.x = 0.5f;
    Triangle[20].pos.y = -0.5f;
    Triangle[20].pos.z = 0.5f;
    Triangle[20].color = XMFLOAT4(0.0f, 1.0f, 1.0f, 1.0f);
    Triangle[20].tex.x = 0.0;
    Triangle[20].tex.y = 0.0;

    Triangle[21].pos.x = 0.5f;
    Triangle[21].pos.y = -0.5f;
    Triangle[21].pos.z = -0.5f;
    Triangle[21].color = XMFLOAT4(0.0f, 1.0f, 1.0f, 1.0f);
    Triangle[21].tex.x = 0.0;
    Triangle[21].tex.y = 1.0;

    Triangle[22].pos.x = -0.5f;
    Triangle[22].pos.y = -0.5f;
    Triangle[22].pos.z = -0.5f;
    Triangle[22].color = XMFLOAT4(0.0f, 1.0f, 1.0f, 1.0f);
    Triangle[22].tex.x = 1.0;
    Triangle[22].tex.y = 1.0;

    Triangle[23].pos.x = -0.5f;
    Triangle[23].pos.y = -0.5f;
    Triangle[23].pos.z = 0.5f;
    Triangle[23].color = XMFLOAT4(0.0f, 1.0f, 1.0f, 1.0f);
    Triangle[23].tex.x = 1.0;
    Triangle[23].tex.y = 0.0;

    XMFLOAT4 acolor = XMFLOAT4(0.1f, 0.75f, 0.75f, 0.6f);
    Triangle[24].pos.x = 0.8f;
    Triangle[24].pos.y = 0.8f;
    Triangle[24].pos.z = 0.0f;
    Triangle[24].normal = XMFLOAT3(0.0f, 0.0f, 1.0f);
    Triangle[24].color = acolor;
    Triangle[24].tex.x = 0.0;
    Triangle[24].tex.y = 0.0;

    Triangle[25].pos.x = 0.8f;
    Triangle[25].pos.y = -0.8f;
    Triangle[25].pos.z = 0.0f;
    Triangle[25].normal = XMFLOAT3(0.0f, 0.0f, 1.0f);
    Triangle[25].color = acolor;
    Triangle[25].tex.x = 0.0;
    Triangle[25].tex.y = 1.0;

    Triangle[26].pos.x = -0.8f;
    Triangle[26].pos.y = -0.8f;
    Triangle[26].pos.z = 0.0f;
    Triangle[26].normal = XMFLOAT3(0.0f, 0.0f, 1.0f);
    Triangle[26].color = acolor;
    Triangle[26].tex.x = 1.0;
    Triangle[26].tex.y = 1.0;

    Triangle[27].pos.x = -0.8f;
    Triangle[27].pos.y = 0.8f;
    Triangle[27].pos.z = 0.0f;
    Triangle[27].normal = XMFLOAT3(0.0f, 0.0f, 1.0f);
    Triangle[27].color = acolor;
    Triangle[27].tex.x = 1.0;
    Triangle[27].tex.y = 0.0;

    Indices[0] = 0;    Indices[1] = 1;    Indices[2] = 2;
    Indices[3] = 2;    Indices[4] = 3;    Indices[5] = 0;

    Indices[6] = 4;    Indices[7] = 5;    Indices[8] = 6;
    Indices[9] = 6;    Indices[10] = 7;    Indices[11] = 4;

    Indices[12] = 8;    Indices[13] = 9;    Indices[14] = 10;
    Indices[15] = 10;    Indices[16] = 11;    Indices[17] = 8;

    Indices[18] = 12;    Indices[19] = 13;    Indices[20] = 14;
    Indices[21] = 14;    Indices[22] = 15;    Indices[23] = 12;

    Indices[24] = 16;    Indices[25] = 17;    Indices[26] = 18;
    Indices[27] = 18;    Indices[28] = 19;    Indices[29] = 16;

    Indices[30] = 20;    Indices[31] = 21;    Indices[32] = 22;
    Indices[33] = 22;    Indices[34] = 23;    Indices[35] = 20;

    Indices[36] = 24;    Indices[37] = 25;
    Indices[38] = 27;    Indices[39] = 26;
}
